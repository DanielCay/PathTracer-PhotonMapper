/***************************************/
   ALEJANDRO GUTIÉRREZ BOLEA - 735089
   DANIEL CAY DELGADO - 741066
/***************************************/

COMPILAR: 
	g++ -std=c++14 -O3 -pthread main.cpp -o <nombreEjecutable>

EJECUTAR: 
	./<nombreEjecutable> <ppp> <width> <height> <nombreImagenSalida>