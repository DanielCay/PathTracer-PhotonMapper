/***************************************/
   ALEJANDRO GUTIÉRREZ BOLEA - 735089
   DANIEL CAY DELGADO - 741066
/***************************************/

COMPILATION 
Inside the Ux folder:
./buildpm.sh

EXECUTION 
./smallpm -scene 1 -film-name file
